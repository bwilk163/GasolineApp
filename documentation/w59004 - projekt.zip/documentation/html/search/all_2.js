var searchData=
[
  ['city',['City',['../class_gasoline_1_1_data_1_1_models_1_1_gas_station.html#a9033f70b9e035a061f48ec316fb9b23f',1,'Gasoline::Data::Models::GasStation']]]
];
