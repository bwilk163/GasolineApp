var searchData=
[
  ['getasync',['GetAsync',['../class_gasoline_1_1_data_1_1_services_1_1_fuel_type_service.html#a9993b394d47b8cb7712fc526bf36e3e0',1,'Gasoline.Data.Services.FuelTypeService.GetAsync()'],['../interface_gasoline_1_1_data_1_1_services_1_1_i_fuel_type_service.html#a3abc3e8b5c004ce0da2645017c971114',1,'Gasoline.Data.Services.IFuelTypeService.GetAsync()']]],
  ['getbyidasync',['GetByIdAsync',['../class_gasoline_1_1_data_1_1_services_1_1_gas_station_service.html#a27d422e0840d24e1a45682f4dd293b7b',1,'Gasoline.Data.Services.GasStationService.GetByIdAsync()'],['../interface_gasoline_1_1_data_1_1_services_1_1_i_gas_station_service.html#addc95df8cbebea3094ad37655746bba2',1,'Gasoline.Data.Services.IGasStationService.GetByIdAsync()']]],
  ['getbyname',['GetByName',['../class_gasoline_1_1_api_1_1_controllers_1_1_fuel_types_controller.html#ae064a5c08e3ebf4f845e95f56ba06ea8',1,'Gasoline::Api::Controllers::FuelTypesController']]],
  ['getgasstationfuels',['GetGasStationFuels',['../class_gasoline_1_1_data_1_1_services_1_1_gas_station_service.html#a1b190190220d302d763a55ce77e7de50',1,'Gasoline.Data.Services.GasStationService.GetGasStationFuels()'],['../interface_gasoline_1_1_data_1_1_services_1_1_i_gas_station_service.html#a6ce56950a33e26aa14da2e8b1b92948b',1,'Gasoline.Data.Services.IGasStationService.GetGasStationFuels()']]]
];
