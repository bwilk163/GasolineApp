var searchData=
[
  ['fuelname',['FuelName',['../class_gasoline_1_1_data_1_1_models_1_1_fuel_type.html#aeb64372fcf61302d2618f5ee46ea6473',1,'Gasoline::Data::Models::FuelType']]]
];
