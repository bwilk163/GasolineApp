var searchData=
[
  ['name',['Name',['../class_gasoline_1_1_data_1_1_models_1_1_gas_station.html#a13a8f1f8a9dfa3a93741e1b6f9817eb6',1,'Gasoline::Data::Models::GasStation']]]
];
