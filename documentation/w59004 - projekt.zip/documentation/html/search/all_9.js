var searchData=
[
  ['removeasync',['RemoveAsync',['../class_gasoline_1_1_api_1_1_controllers_1_1_fuel_types_controller.html#a370af0dd01c9bd075e4c3cb5c4affb6b',1,'Gasoline.Api.Controllers.FuelTypesController.RemoveAsync()'],['../class_gasoline_1_1_data_1_1_services_1_1_fuel_type_service.html#a333515dd73b8936108c16914ed684dee',1,'Gasoline.Data.Services.FuelTypeService.RemoveAsync()'],['../interface_gasoline_1_1_data_1_1_services_1_1_i_fuel_type_service.html#a038bfa7ea9e22a7390c26bda4ed68628',1,'Gasoline.Data.Services.IFuelTypeService.RemoveAsync()']]]
];
