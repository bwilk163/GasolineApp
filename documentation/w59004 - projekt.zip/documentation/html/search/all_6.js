var searchData=
[
  ['id',['Id',['../class_gasoline_1_1_data_1_1_models_1_1_fuel_type.html#a7a41f8fae4838bbaea573dba3094ab61',1,'Gasoline.Data.Models.FuelType.Id()'],['../class_gasoline_1_1_data_1_1_models_1_1_gas_station.html#a9d4760a89b8a64b387f6b14d02aa876d',1,'Gasoline.Data.Models.GasStation.Id()']]],
  ['ifueltypeservice',['IFuelTypeService',['../interface_gasoline_1_1_data_1_1_services_1_1_i_fuel_type_service.html',1,'Gasoline::Data::Services']]],
  ['igasstationservice',['IGasStationService',['../interface_gasoline_1_1_data_1_1_services_1_1_i_gas_station_service.html',1,'Gasoline::Data::Services']]],
  ['init',['init',['../class_gasoline_1_1_data_1_1_migrations_1_1init.html',1,'Gasoline::Data::Migrations']]]
];
