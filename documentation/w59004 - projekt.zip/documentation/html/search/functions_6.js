var searchData=
[
  ['updategasstationasync',['UpdateGasStationAsync',['../class_gasoline_1_1_data_1_1_services_1_1_gas_station_service.html#a71d61038244d2ebd2543e76073c7ac91',1,'Gasoline.Data.Services.GasStationService.UpdateGasStationAsync()'],['../interface_gasoline_1_1_data_1_1_services_1_1_i_gas_station_service.html#ae172cf0f9448fd6c9d24c2ced6b1afdc',1,'Gasoline.Data.Services.IGasStationService.UpdateGasStationAsync()']]],
  ['updategasstationfuelasync',['UpdateGasStationFuelAsync',['../class_gasoline_1_1_data_1_1_services_1_1_gas_station_service.html#ac437b0ab0507030c7f91623fef829461',1,'Gasoline.Data.Services.GasStationService.UpdateGasStationFuelAsync()'],['../interface_gasoline_1_1_data_1_1_services_1_1_i_gas_station_service.html#a88e35520ad60feb8c04c609a47c064ff',1,'Gasoline.Data.Services.IGasStationService.UpdateGasStationFuelAsync()']]]
];
