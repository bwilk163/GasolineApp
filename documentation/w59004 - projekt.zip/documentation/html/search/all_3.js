var searchData=
[
  ['deletegasstation',['DeleteGasStation',['../class_gasoline_1_1_data_1_1_services_1_1_gas_station_service.html#ade4d74ba7e340358a006867f2abe4232',1,'Gasoline.Data.Services.GasStationService.DeleteGasStation()'],['../interface_gasoline_1_1_data_1_1_services_1_1_i_gas_station_service.html#a43d0139d482190c88cbc255af14c7837',1,'Gasoline.Data.Services.IGasStationService.DeleteGasStation()']]],
  ['deletegasstationfuelasync',['DeleteGasStationFuelAsync',['../class_gasoline_1_1_data_1_1_services_1_1_gas_station_service.html#aced2362a8a06e2052178b96980c25b67',1,'Gasoline.Data.Services.GasStationService.DeleteGasStationFuelAsync()'],['../interface_gasoline_1_1_data_1_1_services_1_1_i_gas_station_service.html#a2d8ab6257dbfd8bf3ade23604bf33ca2',1,'Gasoline.Data.Services.IGasStationService.DeleteGasStationFuelAsync()']]]
];
